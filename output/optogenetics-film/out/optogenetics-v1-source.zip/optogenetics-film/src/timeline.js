export const W = 1080, H = 1920, FPS = 30, DUR = 75;
export const ACTS = [
  { id: 'hook', a: 0, b: 5, title: ['神经元，能装上', '光开关吗？'], kicker: '一个问题 · 一束光', note: '预先表达光敏蛋白 · 原理示意' },
  { id: 'target', a: 5, b: 12, title: ['先让特定细胞', '拥有光敏蛋白'], kicker: '01 / 选择目标', note: '表达位置与光照范围，共同影响选择性' },
  { id: 'algae', a: 12, b: 21, title: ['答案，来自', '微生物的光敏蛋白'], kicker: '02 / 找到光敏工具', note: '蛋白结构与表达过程均为示意' },
  { id: 'membrane', a: 21, b: 32, title: ['光打开通道', '离子改变膜电位'], kicker: '03 / 看见隐藏的机制', note: 'ChR2 · 代表性的蓝光激活工具' },
  { id: 'rhythm', a: 32, b: 41, title: ['用光脉冲', '调节放电节奏'], kicker: '04 / 从开关到节奏', note: '条件合适时 · 轨迹为原理示意' },
  { id: 'inhibit', a: 41, b: 49, title: ['另一类工具', '让活动安静下来'], kicker: '05 / 激活，也可以抑制', note: '抑制活动，≠ 关闭整个大脑' },
  { id: 'research', a: 49, b: 57, title: ['这组细胞', '影响什么行为？'], kicker: '06 / 实验中的因果问题', note: '实验动物 · 必须结合对照与实验条件' },
  { id: 'vision', a: 57, b: 66, title: ['一个早期病例', '部分恢复物体辨识'], kicker: '07 / 2021 · 临床研究', note: '基因治疗 + 光刺激眼镜 · 作用于视网膜' },
  { id: 'nobel', a: 66, b: 72, title: ['光遗传学'], kicker: 'OPTOGENETICS', note: '2026 诺贝尔生理学或医学奖' },
  { id: 'ending', a: 72, b: 75, title: ['给神经元装一个', '光开关'], kicker: '一束光，照见回路中的因果', note: '原创代码动画 · 光遗传学原理示意' },
];
export const CAPTIONS = [
  [0, 5, '给神经元装一个光开关，会发生什么？'],
  [5, 12, '关键，是先让特定细胞拥有光敏蛋白。'],
  [12, 16.8, '一些微生物的蛋白，本来就能响应光。'],
  [16.8, 21, '把这类蛋白的编码，引入目标细胞。'],
  [21, 26.2, '光敏通道表达在神经元膜上。'],
  [26.2, 32, '光改变离子流，也就影响了膜电位。'],
  [32, 41, '合适的光脉冲，能调节这些细胞的放电节奏。'],
  [41, 49, '换用另一类光敏工具，也能压低特定细胞的活动。'],
  [49, 57, '在实验条件下，研究者能追问这组细胞的作用。'],
  [57, 61.3, '2021年，研究者报告了一名患者的早期结果。'],
  [61.3, 66, '配合光刺激眼镜，部分恢复了辨识物体的能力。'],
  [66, 72, '把光，变成探索神经回路的工具。'],
  [72, 75, '一束光，照见回路中的因果。'],
];
export const PULSES = [0.9, 2.3, 3.7, 6.7, 8.2, 9.7, 23.2, 25.6, 28.0, 30.0, 33.0, 34.45, 35.9, 37.35, 38.8, 67.3, 68.7, 70.1, 72.3, 73.4];
export const WARM = [42.3, 44.0, 45.7, 47.3];
export const at = t => ACTS.find(s => t >= s.a && t < s.b) || ACTS.at(-1);
export const pulse = (t, times = PULSES, decay = 0.32) => Math.max(0, ...times.map(p => t >= p && t - p < 2 ? Math.exp(-(t - p) / decay) : 0));

const stamp = seconds => {
  const ms = Math.round(seconds * 1000);
  return `${String(Math.floor(ms / 3600000)).padStart(2, '0')}:${String(Math.floor(ms / 60000) % 60).padStart(2, '0')}:${String(Math.floor(ms / 1000) % 60).padStart(2, '0')},${String(ms % 1000).padStart(3, '0')}`;
};
export const srt = () => CAPTIONS.map(([a, b, text], i) => `${i + 1}\n${stamp(a)} --> ${stamp(b)}\n${text}\n`).join('\n');
